#ifndef COMMON_H
#define COMMON_H

int sw = 160, sh = 144;
int w, h;
int ox, oy;

int pw=768,ph=1024;
int pox,poy;

#endif